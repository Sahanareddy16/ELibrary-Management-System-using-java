package screens;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.AbstractButton;

public class Screen6 {

	private JFrame frame;
	private JLabel lblNewLabel;
	private JTable table;
	private JButton btnNewButton;
    private JButton backButton;



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Screen6 window = new Screen6();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Screen6() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scroll = new JScrollPane();
		scroll.setBounds(45, 59, 340, 195);
		frame.getContentPane().add(scroll);
		
		scroll.setVisible(false);
		
		table = new JTable();
		scroll.setViewportView(table);
		
		
		JButton btnNewButton = new JButton("Show All Students");
		lblNewLabel = new JLabel("JTable");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					scroll.setVisible(true);
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
					Statement stmt = con.createStatement();
					String qry = "select * from Studentinfo ";
					ResultSet rs = stmt.executeQuery(qry);
					ResultSetMetaData rmd = rs.getMetaData();
					int cc = rmd.getColumnCount();
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					String[] cols = new String[cc];
					for(int i = 0; i<cc; i++)
						cols[i] = rmd.getColumnName(i+1);
					model.setColumnIdentifiers(cols);
					while(rs.next()) {
						String Sname = rs.getString(1);
						String Sroll= rs.getString(2);
						String Syear= rs.getString(3);
						String Sdept = rs.getString(4);
						String row[] = {Sname,Sroll,Syear,Sdept};
						model.addRow(row);
					}
					
				}
				catch(Exception e1) {e1.printStackTrace();}
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnNewButton.setBounds(90, 11, 207, 37);
		frame.getContentPane().add(btnNewButton);
		
		backButton = new JButton("Back ");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen2 screen2 = new Screen2();
                screen2.setVisible(true);
            }
        });
        backButton.setBounds(307, 15, 124, 32);
        frame.getContentPane().add(backButton);

        frame.setVisible(true);
		
	}
	public void setVisible(boolean b) {
        frame.setVisible(b);
    }
}
