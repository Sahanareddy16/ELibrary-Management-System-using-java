package screens;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Screen3 {

    private JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JButton btnNewButton;
    private JButton backButton;

    public Screen3() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Add New Book");
        lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 15));
        lblNewLabel.setBounds(155, 11, 178, 26);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Enter Serial no of Book");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 15));
        lblNewLabel_1.setBounds(10, 65, 178, 20);
        frame.getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Enter Book Name");
        lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 15));
        lblNewLabel_2.setBounds(10, 101, 165, 26);
        frame.getContentPane().add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("Enter Author Name");
        lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 15));
        lblNewLabel_3.setBounds(10, 138, 165, 26);
        frame.getContentPane().add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("Enter Quantity Of Book");
        lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 15));
        lblNewLabel_4.setBounds(10, 175, 165, 26);
        frame.getContentPane().add(lblNewLabel_4);

        textField = new JTextField();
        textField.setBounds(207, 66, 142, 20);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(207, 105, 142, 20);
        frame.getContentPane().add(textField_1);
        textField_1.setColumns(10);

        textField_2 = new JTextField();
        textField_2.setBounds(207, 142, 142, 20);
        frame.getContentPane().add(textField_2);
        textField_2.setColumns(10);

        textField_3 = new JTextField();
        textField_3.setBounds(207, 179, 142, 20);
        frame.getContentPane().add(textField_3);
        textField_3.setColumns(10);

        btnNewButton = new JButton("Save");
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
                    Statement stmt = con.createStatement();
                    String Sno = textField.getText();
                    String Bookname = textField_1.getText();
                    String Author = textField_2.getText();
                    String Quantity = textField_3.getText();
                    String sql = "insert into Library values('" + Sno + "','" + Bookname + "', '" + Author + "', '" + Quantity + "')";
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(frame, "Information Saved Successfully");
                    @SuppressWarnings("unused")
                    Screen2 sc = new Screen2();
                    frame.setVisible(false);
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });
        btnNewButton.setBounds(20, 221, 85, 33);
        frame.getContentPane().add(btnNewButton);

        backButton = new JButton("Back ");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen2 screen2 = new Screen2();
                screen2.setVisible(true);
            }
        });
        backButton.setBounds(289, 221, 142, 33);
        frame.getContentPane().add(backButton);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Screen3 window = new Screen3();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void setVisible(boolean isVisible) {
        frame.setVisible(isVisible);
    }
}
