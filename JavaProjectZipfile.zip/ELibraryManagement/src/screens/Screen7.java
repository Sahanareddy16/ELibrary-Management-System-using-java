package screens;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class Screen7 {

    private JFrame frame;
    private JLabel lblNewLabel;
    private JTable table;
    private JTextField searchField;
    private JButton btnNewButton;
    private JButton backButton;


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Screen7 window = new Screen7();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Screen7() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JScrollPane scroll = new JScrollPane();
        scroll.setBounds(345, 56, 71, 45);
        frame.getContentPane().add(scroll);
        scroll.setVisible(false);

        table = new JTable();
        scroll.setViewportView(table);

        searchField = new JTextField();
        searchField.setBounds(20, 21, 189, 31);
        frame.getContentPane().add(searchField);

        JButton searchButton = new JButton("Search Book");
        searchButton.setBounds(220, 21, 166, 31);

        lblNewLabel = new JLabel("JTable");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String searchValue = searchField.getText();
                searchBook(searchValue);
            }
        });

        frame.getContentPane().setLayout(null);
        searchButton.setFont(new Font("Arial Black", Font.PLAIN, 14));
        frame.getContentPane().add(searchButton);

        JButton showAllBooksButton = new JButton("Show All Books");
        showAllBooksButton.setBounds(103, 70, 189, 31);
        showAllBooksButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAllBooks();
            }
        });

        frame.getContentPane().setLayout(null);
        showAllBooksButton.setFont(new Font("Arial Black", Font.PLAIN, 14));
        frame.getContentPane().add(showAllBooksButton);

        table = new JTable();
        table.setBounds(20, 115, 396, 125);
        frame.getContentPane().add(table);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 14));
        backButton.setBounds(10, 71, 83, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                goBackToPreviousScreen();
            }
        });
        frame.getContentPane().add(backButton);
    }

    private void goBackToPreviousScreen() {
        frame.dispose();
        Screen2 screen2 = new Screen2();
        screen2.setVisible(true);
    }

    private void showAllBooks() {
        try {
            JScrollPane scroll = new JScrollPane();
            scroll.setBounds(20, 115, 396, 125);
            frame.getContentPane().add(scroll);
            scroll.setVisible(true);

            table = new JTable();
            scroll.setViewportView(table);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
            Statement stmt = con.createStatement();
            String qry = "select * from library";
            ResultSet rs = stmt.executeQuery(qry);
            ResultSetMetaData rmd = rs.getMetaData();
            int cc = rmd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            String[] cols = new String[cc];
            for (int i = 0; i < cc; i++)
                cols[i] = rmd.getColumnName(i + 1);
            model.setColumnIdentifiers(cols);
            while (rs.next()) {
                String Sno = rs.getString(1);
                String Bookname = rs.getString(2);
                String Author = rs.getString(3);
                String Quantity = rs.getString(4);
                String row[] = {Sno, Bookname, Author, Quantity};
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void searchBook(String searchValue) {
        try {
            JScrollPane scroll = new JScrollPane();
            scroll.setBounds(20, 115, 396, 125);
            frame.getContentPane().add(scroll);
            scroll.setVisible(true);

            table = new JTable();
            scroll.setViewportView(table);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
            Statement stmt = con.createStatement();
            String qry = "SELECT * FROM library WHERE Bookname = '" + searchValue + "' OR Author = '" + searchValue + "'";
            ResultSet rs = stmt.executeQuery(qry);
            ResultSetMetaData rmd = rs.getMetaData();
            int cc = rmd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            String[] cols = new String[cc];
            for (int i = 0; i < cc; i++)
                cols[i] = rmd.getColumnName(i + 1);
            model.setColumnIdentifiers(cols);
            boolean bookFound = false;

            while (rs.next()) {
                String Sno = rs.getString(1);
                String Bookname = rs.getString(2);
                String Author = rs.getString(3);
                String Quantity = rs.getString(4);
                String row[] = {Sno, Bookname, Author, Quantity};
                model.addRow(row);
                bookFound = true;
            }

            if (!bookFound) {
                JOptionPane.showMessageDialog(frame, "No such book present", "Book Not Found", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
  
		
    }
    public void setVisible(boolean b) {
        frame.setVisible(b);
    }
}
