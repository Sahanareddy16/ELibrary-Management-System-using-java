package screens;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.sql.ResultSet; // Add this import statement

public class Screen9 {

    private JFrame frame;
    private JTextField textFieldRollNo;
    private JTextField textFieldSerialNo;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Screen9 window = new Screen9();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Screen9() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblEnterRollNo = new JLabel("Enter Roll No");
        lblEnterRollNo.setFont(new Font("Arial", Font.PLAIN, 14));
        lblEnterRollNo.setBounds(33, 75, 120, 24);
        frame.getContentPane().add(lblEnterRollNo);

        JLabel lblEnterSerialNo = new JLabel("Enter Book Serial No");
        lblEnterSerialNo.setFont(new Font("Arial", Font.PLAIN, 14));
        lblEnterSerialNo.setBounds(33, 146, 160, 24);
        frame.getContentPane().add(lblEnterSerialNo);

        textFieldRollNo = new JTextField();
        textFieldRollNo.setBounds(227, 78, 145, 20);
        frame.getContentPane().add(textFieldRollNo);
        textFieldRollNo.setColumns(10);

        textFieldSerialNo = new JTextField();
        textFieldSerialNo.setBounds(227, 149, 145, 20);
        frame.getContentPane().add(textFieldSerialNo);
        textFieldSerialNo.setColumns(10);

        JButton btnBorrow = new JButton("Borrow Book");
        btnBorrow.setFont(new Font("Arial", Font.PLAIN, 14));
        btnBorrow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String Srollno = textFieldRollNo.getText();
                String Sno = textFieldSerialNo.getText();

                // Use your connection code to connect to the database
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");

                    // Check if the book is available in the library
                    String checkAvailabilityQuery = "SELECT * FROM library WHERE  Sno = ?";
                    PreparedStatement checkAvailabilityStmt = con.prepareStatement(checkAvailabilityQuery);
                    checkAvailabilityStmt.setString(1, Sno);
                    ResultSet result = checkAvailabilityStmt.executeQuery();

                    if (result.next()) {
                        // Book is available, insert the borrowing record
                        String insertQuery = "INSERT INTO BorrowedBooks (Srollno, BSno) VALUES (?, ?)";
                        PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                        insertStmt.setString(1, Srollno);
                        insertStmt.setString(2, Sno);
                        insertStmt.executeUpdate();

                        JOptionPane.showMessageDialog(frame, "Book borrowed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        // Book is not available
                        JOptionPane.showMessageDialog(frame, "Book is not available!", "Unavailable", JOptionPane.WARNING_MESSAGE);
                    }

                    // Close the database connection
                    con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnBorrow.setBounds(134, 190, 145, 23);
        frame.getContentPane().add(btnBorrow);
        
        JButton btnSubmit = new JButton("Submit Book");
        btnSubmit.setFont(new Font("Arial", Font.PLAIN, 14));
        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String Srollno = textFieldRollNo.getText();
                String BSno = textFieldSerialNo.getText();

                // Use your connection code to connect to the database
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");

                    // Check if the book is borrowed by the student
                    String checkBorrowedQuery = "SELECT * FROM BorrowedBooks WHERE Srollno = ? AND BSno = ?";
                    PreparedStatement checkBorrowedStmt = con.prepareStatement(checkBorrowedQuery);
                    checkBorrowedStmt.setString(1, Srollno);
                    checkBorrowedStmt.setString(2, BSno);
                    ResultSet result = checkBorrowedStmt.executeQuery();

                    if (result.next()) {
                        // Book is borrowed by the student, remove the borrowing record
                        String deleteQuery = "DELETE FROM BorrowedBooks WHERE Srollno = ? AND BSno = ?";
                        PreparedStatement deleteStmt = con.prepareStatement(deleteQuery);
                        deleteStmt.setString(1, Srollno);
                        deleteStmt.setString(2, BSno);
                        deleteStmt.executeUpdate();

                        JOptionPane.showMessageDialog(frame, "Book submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        // Book is not borrowed by the student
                        JOptionPane.showMessageDialog(frame, "You did not borrow this book!", "Not Borrowed", JOptionPane.WARNING_MESSAGE);
                    }

                    // Close the database connection
                    con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnSubmit.setBounds(134, 220, 145, 23);
        frame.getContentPane().add(btnSubmit);
    
    JButton btnBack = new JButton("Back");
    btnBack.setFont(new Font("Arial", Font.PLAIN, 14));
    btnBack.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Implement the code to go back to the previous screen (e.g., Screen2)
            goBackToScreen2();
        }
    });
    btnBack.setBounds(332, 216, 80, 30);
    frame.getContentPane().add(btnBack);
}

   private void goBackToScreen2() {
    frame.dispose();
    Screen2 screen2 = new Screen2();
    screen2.setVisible(true);
}
   public void setVisible(boolean isVisible) {
       frame.setVisible(isVisible);
   }
}
