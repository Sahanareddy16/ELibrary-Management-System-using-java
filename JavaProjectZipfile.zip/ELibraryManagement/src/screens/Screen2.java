package screens;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Screen2 {
    private JFrame frame;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Screen2 window = new Screen2();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Screen2() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Button to open Screen3
        JButton btnNewButton_1 = new JButton("Add New Book");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen3 sc = new Screen3();
                sc.setVisible(true);
            }
        });
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 15));
        btnNewButton_1.setBounds(27, 23, 155, 35);
        frame.getContentPane().add(btnNewButton_1);

        // Button to open Screen4
        JButton btnNewButton_4 = new JButton("Register Student");
        btnNewButton_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen4 sc = new Screen4();
                sc.setVisible(true);
            }
        });
        btnNewButton_4.setFont(new Font("Arial", Font.PLAIN, 15));
        btnNewButton_4.setBounds(237, 22, 155, 36);
        frame.getContentPane().add(btnNewButton_4);

        // Button to open Screen5
        JButton btnNewButton_5 = new JButton("Show All Books");
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen5 sc = new Screen5();
                sc.setVisible(true);
            }
        });
        btnNewButton_5.setFont(new Font("Arial", Font.PLAIN, 15));
        btnNewButton_5.setBounds(30, 69, 155, 36);
        frame.getContentPane().add(btnNewButton_5);

        // Button to open Screen6
        JButton btnNewButton_6 = new JButton("Show All Students");
        btnNewButton_6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen6 sc = new Screen6();
                sc.setVisible(true);
            }
        });
        btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
        btnNewButton_6.setBounds(237, 69, 155, 35);
        frame.getContentPane().add(btnNewButton_6);

        // Button to open Screen7 for searching a book
        JButton btnNewButton_7 = new JButton("Search a Book ");
        btnNewButton_7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen7 sc = new Screen7();
                sc.setVisible(true);
            }
        });
        btnNewButton_7.setFont(new Font("Arial", Font.PLAIN, 15));
        btnNewButton_7.setBounds(27, 116, 157, 35);
        frame.getContentPane().add(btnNewButton_7);

        JButton searchStudentButton = new JButton("Search a Student");
        searchStudentButton.setBounds(237, 115, 155, 35);
        searchStudentButton.setFont(new Font("Arial", Font.PLAIN, 14));
        frame.getContentPane().add(searchStudentButton);

        searchStudentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen8 screen8 = new Screen8();
                screen8.setVisible(true);
            }
        });

        JButton borrowButton = new JButton("Borrow or Submit");
        borrowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                Screen9 screen9 = new Screen9();
                screen9.setVisible(true);
            }
        });
        borrowButton.setFont(new Font("Arial", Font.PLAIN, 15));
        borrowButton.setBounds(27, 162, 158, 35); // Adjusted the Y-position
        frame.getContentPane().add(borrowButton);

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exit the application
            }
        });
        exitButton.setFont(new Font("Arial", Font.PLAIN, 15));
        exitButton.setBounds(237, 162, 155, 35);
        frame.getContentPane().add(exitButton);
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }
}
