package screens;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class Screen8 {

    private JFrame frame;
    private JTable table;
    private JTextField searchField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Screen8 window = new Screen8();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Screen8() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        searchField = new JTextField();
        searchField.setBounds(45, 10, 189, 31);
        frame.getContentPane().add(searchField);

        JButton searchButton = new JButton("Search Student");
        searchButton.setFont(new Font("Arial", Font.PLAIN, 15));
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String searchValue = searchField.getText();
                searchStudent(searchValue);
            }
        });
        searchButton.setBounds(244, 10, 141, 31);
        frame.getContentPane().add(searchButton);

        JButton showAllButton = new JButton("Show All Students");
        showAllButton.setFont(new Font("Arial Black", Font.PLAIN, 15));
        showAllButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAllStudents();
            }
        });
        showAllButton.setBounds(90, 60, 207, 37);
        frame.getContentPane().add(showAllButton);

        JScrollPane scroll = new JScrollPane();
        scroll.setBounds(45, 100, 340, 154);
        frame.getContentPane().add(scroll);
        scroll.setVisible(false);

        table = new JTable();
        scroll.setViewportView(table);
        
        JButton backButton = new JButton("Back");
        backButton.setBounds(10, 52, 65, 37);
        frame.getContentPane().add(backButton);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                goBackToScreen2();
            }
        });
    }

    private void goBackToScreen2() {
        frame.dispose();
        Screen2 screen2 = new Screen2();
        screen2.setVisible(true);
    }

    private void showAllStudents() {
        try {
            JScrollPane scroll = new JScrollPane();
            scroll.setBounds(45, 100, 340, 154);
            frame.getContentPane().add(scroll);
            scroll.setVisible(true);

            table = new JTable();
            scroll.setViewportView(table);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
            Statement stmt = con.createStatement();
            String qry = "select * from Studentinfo ";
            ResultSet rs = stmt.executeQuery(qry);
            ResultSetMetaData rmd = rs.getMetaData();
            int cc = rmd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            String[] cols = new String[cc];
            for (int i = 0; i < cc; i++)
                cols[i] = rmd.getColumnName(i + 1);
            model.setColumnIdentifiers(cols);
            while (rs.next()) {
                String Sname = rs.getString(1);
                String Sroll = rs.getString(2);
                String Syear = rs.getString(3);
                String Sdept = rs.getString(4);
                String row[] = {Sname, Sroll, Syear, Sdept};
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void searchStudent(String searchValue) {
        try {
            JScrollPane scroll = new JScrollPane();
            scroll.setBounds(45, 100, 340, 154);
            frame.getContentPane().add(scroll);
            scroll.setVisible(true);

            table = new JTable();
            scroll.setViewportView(table);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
            Statement stmt = con.createStatement();
            String qry = "SELECT * FROM Studentinfo WHERE Sname = '" + searchValue + "' OR Sroll = '" + searchValue + "'";
            ResultSet rs = stmt.executeQuery(qry);
            ResultSetMetaData rmd = rs.getMetaData();
            int cc = rmd.getColumnCount();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            String[] cols = new String[cc];
            for (int i = 0; i < cc; i++)
                cols[i] = rmd.getColumnName(i + 1);
            model.setColumnIdentifiers(cols);
            boolean studentFound = false;

            while (rs.next()) {
                String Sname = rs.getString(1);
                String Sroll = rs.getString(2);
                String Syear = rs.getString(3);
                String Sdept = rs.getString(4);
                String row[] = {Sname, Sroll, Syear, Sdept};
                model.addRow(row);
                studentFound = true;
            }

            if (!studentFound) {
                JOptionPane.showMessageDialog(frame, "No such student present", "Student Not Found", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }
}
